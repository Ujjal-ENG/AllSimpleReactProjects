©️ Ujjal Kumar Roy
