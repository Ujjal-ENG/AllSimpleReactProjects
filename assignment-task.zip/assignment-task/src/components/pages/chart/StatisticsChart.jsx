import React from 'react';

const StatisticsChart = () => {
    return <div>StatisticsChart</div>;
};

export default StatisticsChart;
